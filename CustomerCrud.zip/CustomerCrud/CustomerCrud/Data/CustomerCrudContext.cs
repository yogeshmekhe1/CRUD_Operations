﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CustomerCrud.Model;

namespace CustomerCrud.Data
{
    public class CustomerCrudContext : DbContext
    {
        public CustomerCrudContext (DbContextOptions<CustomerCrudContext> options)
            : base(options)
        {
        }

        public DbSet<CustomerCrud.Model.Customer> Customer { get; set; } = default!;
    }
}
